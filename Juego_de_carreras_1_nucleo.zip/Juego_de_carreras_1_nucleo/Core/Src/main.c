/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stdlib.h>       // Librería estándar para funciones como dtostrf
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t contador1 = 0;
uint8_t contador2 = 0;
uint8_t estado = 0;
uint8_t ganador = 0;
uint8_t leds1 = 0;
uint8_t leds2 = 0;
uint8_t dato = 0;
uint8_t display = 2;
const uint8_t cinco = 0b10010010;   // Configuración para el número "5"
const uint8_t cuatro = 0b10011001;  // Configuración para el número "4"
const uint8_t tres = 0b10110000;    // Configuración para el número "3"
const uint8_t dos = 0b10100100;     // Configuración para el número "2"
const uint8_t uno = 0b11111001;     // Configuración para el número "1"
const uint8_t cero = 0b11000000;    // Configuración para el número "0"

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */
void valordispl(uint8_t numero);
void reseteocontadores(void);
void conteoRegresivo(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  ganador = 0;
  contador1 = 0;
  contador2 = 0;
  estado = 0;
  leds1 = 0;
  leds2 = 0;
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
if(display == 0){
	conteoRegresivo();
	//reseteocontadores();
}
  if(display == 1){
		if (estado == 1){
		  if(ganador != 2 && contador2 != 4){
			  if(contador1 <4){
					HAL_GPIO_WritePin(PC0_GPIO_Port, PC0_Pin, (leds1 >> 0) & 1);
				    HAL_GPIO_WritePin(PC1_GPIO_Port, PC1_Pin, (leds1 >> 1) & 1);
					HAL_GPIO_WritePin(PC2_GPIO_Port, PC2_Pin, (leds1 >> 2) & 1);
					HAL_GPIO_WritePin(PC3_GPIO_Port, PC3_Pin, (leds1 >> 3) & 1);
			  }
			  else if(contador1 == 4){
						ganador = 1;
					}
				estado = 0;
		  }
		}
		else if (estado == 2){
		  if(ganador != 1 && contador1 != 4){
			//}
			//else if(estado == 2){
				//contador2++;
				if(contador2 < 4){
					HAL_GPIO_WritePin(PB0_GPIO_Port, PB0_Pin, (leds2 >> 0) & 1);
				    HAL_GPIO_WritePin(PB1_GPIO_Port, PB1_Pin, (leds2 >> 1) & 1);
					HAL_GPIO_WritePin(PB2_GPIO_Port, PB2_Pin, (leds2 >> 2) & 1);
					HAL_GPIO_WritePin(PB3_GPIO_Port, PB3_Pin, (leds2 >> 3) & 1);
				}
				else if(contador2 == 4){
					ganador = 2;
				}
				estado = 0;
		  }
		}
		  if(ganador == 1){

			  contador1 = 4;
			  contador2 = 0;
			HAL_GPIO_WritePin(PC0_GPIO_Port, PC0_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PC1_GPIO_Port, PC1_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PC2_GPIO_Port, PC2_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PC3_GPIO_Port, PC3_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PB0_GPIO_Port, PB0_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PB1_GPIO_Port, PB1_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PB2_GPIO_Port, PB2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PB3_GPIO_Port, PB3_Pin, GPIO_PIN_RESET);
			valordispl(uno);
			//ganador == 1;
		  }
		  if (ganador == 2){

			    contador2 = 4;
			    contador1 = 0;
				HAL_GPIO_WritePin(PB0_GPIO_Port, PB0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(PB1_GPIO_Port, PB1_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(PB2_GPIO_Port, PB2_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(PB3_GPIO_Port, PB3_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(PC0_GPIO_Port, PC0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(PC1_GPIO_Port, PC1_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(PC2_GPIO_Port, PC2_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(PC3_GPIO_Port, PC3_Pin, GPIO_PIN_RESET);
				valordispl(dos);
				//ganador == 2;
		  }
		  HAL_Delay(200);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, PC0_Pin|PC1_Pin|PC2_Pin|PC3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, PB0_Pin|PB1_Pin|PB2_Pin|G_Pin
                          |PB3_Pin|A_Pin|B_Pin|C_Pin
                          |D_Pin|E_Pin|F_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC0_Pin PC1_Pin PC2_Pin PC3_Pin */
  GPIO_InitStruct.Pin = PC0_Pin|PC1_Pin|PC2_Pin|PC3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : BTN2_Pin */
  GPIO_InitStruct.Pin = BTN2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(BTN2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : BTN3_Pin */
  GPIO_InitStruct.Pin = BTN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(BTN3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0_Pin PB1_Pin PB2_Pin G_Pin
                           PB3_Pin A_Pin B_Pin C_Pin
                           D_Pin E_Pin F_Pin */
  GPIO_InitStruct.Pin = PB0_Pin|PB1_Pin|PB2_Pin|G_Pin
                          |PB3_Pin|A_Pin|B_Pin|C_Pin
                          |D_Pin|E_Pin|F_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : BTN1_Pin */
  GPIO_InitStruct.Pin = BTN1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(BTN1_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void conteoRegresivo() {

    if (display == 0) {
    			//cba
    	valordispl(cinco);        // Muestra "5"
        HAL_Delay(1000);          // Pausa de 1 segundo
        valordispl(cuatro);       // Muestra "4"
        HAL_Delay(1000);
        valordispl(tres);         // Muestra "3"
        HAL_Delay(1000);
        valordispl(dos);          // Muestra "2"
        HAL_Delay(1000);
        valordispl(uno);          // Muestra "1"
        HAL_Delay(1000);
        valordispl(cero);         // Muestra "0"
        HAL_Delay(1000);
        display = 1;              // Cambia el estado para no repetir
    }
}

void valordispl(uint8_t numero){
	HAL_GPIO_WritePin(A_GPIO_Port, A_Pin, (numero & 0b00000001)); // Bit menos significativo no cambia
	HAL_GPIO_WritePin(B_GPIO_Port, B_Pin, (numero & 0b00000010) >> 1);
	HAL_GPIO_WritePin(C_GPIO_Port, C_Pin, (numero & 0b00000100) >> 2);
	HAL_GPIO_WritePin(D_GPIO_Port, D_Pin, (numero & 0b00001000) >> 3);
	HAL_GPIO_WritePin(E_GPIO_Port, E_Pin, (numero & 0b00010000) >> 4);
	HAL_GPIO_WritePin(F_GPIO_Port, F_Pin, (numero & 0b00100000) >> 5);
	HAL_GPIO_WritePin(G_GPIO_Port, G_Pin, (numero & 0b01000000) >> 6);

}
void reseteocontadores(void){
		contador1 = 0;
		contador2 = 0;
		ganador = 0;
		leds1 = 0;
		HAL_GPIO_WritePin(PC0_GPIO_Port, PC0_Pin, (leds1 >> 0) & 1);
		HAL_GPIO_WritePin(PC1_GPIO_Port, PC1_Pin, (leds1 >> 1) & 1);
		HAL_GPIO_WritePin(PC2_GPIO_Port, PC2_Pin, (leds1 >> 2) & 1);
		HAL_GPIO_WritePin(PC3_GPIO_Port, PC3_Pin, (leds1 >> 3) & 1);
		leds2 = 0;
		HAL_GPIO_WritePin(PB0_GPIO_Port, PB0_Pin, (leds2 >> 0) & 1);
		HAL_GPIO_WritePin(PB1_GPIO_Port, PB1_Pin, (leds2 >> 1) & 1);
		HAL_GPIO_WritePin(PB2_GPIO_Port, PB2_Pin, (leds2 >> 2) & 1);
		HAL_GPIO_WritePin(PB3_GPIO_Port, PB3_Pin, (leds2 >> 3) & 1);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    static uint32_t last_interrupt_time = 0;
    uint32_t current_time = HAL_GetTick(); // Obtiene el tiempo actual en ms

    if ((current_time - last_interrupt_time) < 300) { // Tiempo mínimo entre interrupciones (300 ms)
        return; // Ignora la interrupción (rebote)
    }
    last_interrupt_time = current_time;

    // Asegúrate de limitar leds1 a 4 bits inferiores y leds2 a los 4 bits superiores
    if ((GPIO_Pin == BTN2_Pin) && (display == 1)) {
        if (contador1 < 4) {
            contador1++;
            estado = 1;
        switch(contador1){
        case 1:
        	leds1 = 1;
        break;
        case 2:
        	leds1 = 2;
        break;
        case 3:
        	leds1 = 4;
        break;
        case 4:
        	leds1 = 8;
        break;
        default:
        break;
        }
        }
        }
        //contador2 = 0; // Resetea contador2 si BTN1 es presionado
	else if ((GPIO_Pin == BTN1_Pin) && (display == 1)) {
        if (contador2 < 4) {
            contador2++;
            estado = 2;
        }
        switch(contador2){
        case 1:
        	leds2 = 1;
        break;
        case 2:
        	leds2 = 2;
        break;
        case 3:
        	leds2 = 4;
        break;
        case 4:
        	leds2 = 8;
        break;
        default:
        break;
        }
        //contador1 = 0; // Resetea contador1 si BTN2 es presionado
    }
	else if (GPIO_Pin == BTN3_Pin){
		display = 0;
		reseteocontadores();
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
